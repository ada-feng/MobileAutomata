public class S4 implements IState {
	int BLUE=0;
	int WHITE = 1;
	int YELLOW =2;
	int RED = 3;
	int DELTA = 4;

	public int getWriting(int contentRead) {
		if (contentRead == WHITE) {
			return WHITE;
		}
		else if (contentRead == RED) {
			return RED;
		}
		else if (contentRead == BLUE) {
			return BLUE;
		}else if (contentRead == YELLOW) {
			return YELLOW;
		}else{
			return -1;
		}
	}

	public char getDir(int contentRead) {
		if (contentRead == WHITE) {
				return 'L';
		}else if (contentRead == RED) {
			return 'D';
		}else if (contentRead == YELLOW) {
				return 'D';
		}else if (contentRead == BLUE) {
				return 'L';
		}else {
			return -1;
		}
	}

	public IState nextState(int contentRead) {
		if (contentRead == WHITE) {
				return ((IState)new S7());
		}else if (contentRead == RED) {
			return ((IState)new SB());
		}else if (contentRead == YELLOW) {
			return (IState)new SB();
		}else if (contentRead == BLUE) {
			return ((IState)new S7());
		}
		else {
			return (IState)new SE(); //should not be reached
		}
	}



}
