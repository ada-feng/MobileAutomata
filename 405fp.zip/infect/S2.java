public class S2 implements IState {
	int BLUE=0;
	int WHITE = 1;
	int YELLOW =2;
	int RED = 3;
	int DELTA = 4;

	public int getWriting(int contentRead) {
		if (contentRead == WHITE) {
			return WHITE;
		}
		else if (contentRead == RED) {
			return RED;
		}
		else if (contentRead == BLUE) {
			return BLUE;
		}else if (contentRead == YELLOW) {
			return YELLOW;
		}
		else if(contentRead == DELTA) {
			return DELTA;
		}else{
			return -1;
		}
	}

	public char getDir(int contentRead) {
		if (contentRead == WHITE) {
				return 'L';
		}else if (contentRead == RED) {
			return 'D';
		}	else if (contentRead == BLUE) {
				return 'L';
		}else if (contentRead == YELLOW) {
				return 'L';
		}else if (contentRead == DELTA) {
			return 'D';
		}
		else {
			return -1;
		}
	}
	
	public IState nextState(int contentRead) {
		if (contentRead == WHITE) {
				return ((IState)new S5());
		}
		else if (contentRead == RED) {
			return ((IState)new SA());
		}
		else if (contentRead == BLUE) {
			return ((IState)new S4());
		}else if (contentRead == YELLOW) {
			return (IState)new S5();
		}
		else if (contentRead == DELTA) {
			return (IState)new SC1();
		}
		else {
			return (IState)new SE(); //should not be reached
		}
	}



}
