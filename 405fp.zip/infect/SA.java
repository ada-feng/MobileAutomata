public class SA implements IState {
	int BLUE=0;
	int WHITE = 1;
	int YELLOW =2;
	int RED = 3;
	int DELTA = 4;

	public int getWriting(int contentRead) {
		if( contentRead == BLUE || contentRead == RED || contentRead == YELLOW || contentRead == WHITE ||contentRead == DELTA )
			return contentRead;;
		}else{
			return -1;

	}
	public IState nextState(int contentRead) {
		 if (contentRead == WHITE) {
			return ((IState)new S2());
		}
		 else if (contentRead == DELTA) {
			return ((IState)new SC1());
		 }
		else {
		 return (IState)new SA());
		}
	}
	public char getDir(int contentRead) {
		if (contentRead == DELTA){
			return 'D';
		}else if( contentRead == BLUE || contentRead == RED || contentRead == YELLOW || contentRead == WHITE )
			return 'R';
		}else{
			return 'E'; //should not be reached
		}
	}

}
